#include "mainwindow.h"
#include "downloader.hpp" // (Предполагаем наличие заголовков)
#include "xlsx_converter.hpp"
#include "importer.hpp"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPushButton>
#include <QLabel>
#include <QTabWidget>
#include <QTableView>
#include <QLineEdit>
#include <QHeaderView>
#include <QMessageBox>
#include <QFileDialog>
#include <QTextEdit>
#include <QApplication>

MainWindow::MainWindow(Db& db, const User& user, QWidget *parent)
    : QMainWindow(parent), m_db(db), m_user(user), m_threats(db)
{
    setupUi();
}

void MainWindow::setupUi() {
    resize(1000, 700);
    setWindowTitle("Threat Intelligence Platform"); // Звучит солиднее

    QWidget *central = new QWidget(this);
    setCentralWidget(central);
    QVBoxLayout *mainLayout = new QVBoxLayout(central);
    mainLayout->setContentsMargins(0,0,0,0);
    mainLayout->setSpacing(0);

    // Верхняя панель (Header)
    QWidget *header = new QWidget();
    header->setStyleSheet("background-color: #202225; border-bottom: 1px solid #101113;");
    header->setFixedHeight(60);
    QHBoxLayout *headerLayout = new QHBoxLayout(header);
    
    QLabel *logo = new QLabel("🛡️ BDU Client", header);
    logo->setStyleSheet("font-size: 18px; font-weight: bold; color: white; border: none;");
    
    QLabel *userInfo = new QLabel(QString::fromStdString(m_user.login) + (m_user.is_admin() ? " [ADMIN]" : ""), header);
    userInfo->setStyleSheet("color: #b9bbbe; font-size: 14px; border: none;");
    userInfo->setAlignment(Qt::AlignRight | Qt::AlignVCenter);

    headerLayout->addWidget(logo);
    headerLayout->addStretch();
    headerLayout->addWidget(userInfo);

    mainLayout->addWidget(header);

    // Основная область с табами
    QTabWidget *tabs = new QTabWidget(this);
    tabs->setStyleSheet("border: none;"); // Убираем рамки вокруг табов для чистоты
    mainLayout->addWidget(tabs);

    // --- TAB 1: SEARCH ---
    QWidget *searchTab = new QWidget();
    QVBoxLayout *searchLayout = new QVBoxLayout(searchTab);
    searchLayout->setContentsMargins(20, 20, 20, 20); // Отступы внутри таба
    searchLayout->setSpacing(15);

    QHBoxLayout *searchBar = new QHBoxLayout();
    searchEdit = new QLineEdit();
    searchEdit->setPlaceholderText("🔍 Поиск по базе (CVE, название, описание)...");
    searchEdit->setFixedHeight(40);
    
    QPushButton *btnSearch = new QPushButton("Найти");
    btnSearch->setFixedHeight(40);
    btnSearch->setCursor(Qt::PointingHandCursor);

    searchBar->addWidget(searchEdit);
    searchBar->addWidget(btnSearch);
    
    searchTable = new QTableView();
    searchModel = new QStandardItemModel(this);
    searchModel->setHorizontalHeaderLabels({"Код", "Название", "Описание"});
    searchTable->setModel(searchModel);
    searchTable->horizontalHeader()->setSectionResizeMode(1, QHeaderView::Stretch);
    searchTable->verticalHeader()->setVisible(false); // Скрываем номера строк
    searchTable->setAlternatingRowColors(true); // Чередование цветов строк
    
    QPushButton *btnAdd = new QPushButton("➕ Добавить в отчет");
    btnAdd->setCursor(Qt::PointingHandCursor);

    searchLayout->addLayout(searchBar);
    searchLayout->addWidget(searchTable);
    searchLayout->addWidget(btnAdd);
    
    tabs->addTab(searchTab, "Поиск");

    connect(btnSearch, &QPushButton::clicked, this, &MainWindow::onSearch);
    connect(btnAdd, &QPushButton::clicked, this, &MainWindow::onAddToReport);
    // Поиск по Enter
    connect(searchEdit, &QLineEdit::returnPressed, this, &MainWindow::onSearch);

    // --- TAB 2: REPORT ---
    QWidget *reportTab = new QWidget();
    QVBoxLayout *reportLayout = new QVBoxLayout(reportTab);
    reportLayout->setContentsMargins(20, 20, 20, 20);
    
    reportTable = new QTableView();
    reportModel = new QStandardItemModel(this);
    reportModel->setHorizontalHeaderLabels({"Код", "Название"});
    reportTable->setModel(reportModel);
    reportTable->horizontalHeader()->setSectionResizeMode(1, QHeaderView::Stretch);
    reportTable->verticalHeader()->setVisible(false);

    QPushButton *btnExport = new QPushButton("💾 Экспорт в CSV");
    btnExport->setStyleSheet("background-color: #3ba55c;"); // Green for success action
    btnExport->setCursor(Qt::PointingHandCursor);

    reportLayout->addWidget(new QLabel("Сформированный отчет:"));
    reportLayout->addWidget(reportTable);
    reportLayout->addWidget(btnExport);
    tabs->addTab(reportTab, "Отчет");

    connect(btnExport, &QPushButton::clicked, this, &MainWindow::onExportReport);

    // --- TAB 3: ADMIN ---
    if (m_user.is_admin()) {
        QWidget *adminTab = new QWidget();
        QVBoxLayout *adminLayout = new QVBoxLayout(adminTab);
        adminLayout->setContentsMargins(20, 20, 20, 20);
        adminLayout->setSpacing(15);
        
        QPushButton *btnUpdate = new QPushButton("🔄 Обновить базу данных (FSTEC)");
        btnUpdate->setFixedHeight(50);
        btnUpdate->setStyleSheet("background-color: #FAA61A; color: black; font-weight: bold;");
        btnUpdate->setCursor(Qt::PointingHandCursor);

        historyTable = new QTableView();
        historyModel = new QStandardItemModel(this);
        historyModel->setHorizontalHeaderLabels({"Дата", "Админ", "Доб.", "Обн.", "Источник"});
        historyTable->setModel(historyModel);
        historyTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
        historyTable->verticalHeader()->setVisible(false);
        
        QPushButton *btnRefresh = new QPushButton("Обновить историю");
        
        adminLayout->addWidget(new QLabel("<h3>Управление данными</h3>"));
        adminLayout->addWidget(btnUpdate);
        adminLayout->addSpacing(20);
        adminLayout->addWidget(new QLabel("<h3>История обновлений</h3>"));
        adminLayout->addWidget(historyTable);
        adminLayout->addWidget(btnRefresh);

        tabs->addTab(adminTab, "Админка");
        
        connect(btnUpdate, &QPushButton::clicked, this, &MainWindow::onUpdateDatabase);
        connect(btnRefresh, &QPushButton::clicked, this, &MainWindow::onRefreshHistory);
    }

    // --- LOG AREA (внизу) ---
    QWidget *footer = new QWidget();
    footer->setFixedHeight(120);
    footer->setStyleSheet("background-color: #202225; padding: 10px;");
    QVBoxLayout *footerLayout = new QVBoxLayout(footer);
    footerLayout->setContentsMargins(10, 5, 10, 5);

    logArea = new QTextEdit();
    logArea->setReadOnly(true);
    logArea->setStyleSheet("background-color: #101113; color: #00ff00; font-family: Consolas, monospace; border: none;");
    
    footerLayout->addWidget(new QLabel("System Log:", footer));
    footerLayout->addWidget(logArea);

    mainLayout->addWidget(footer);
}

void MainWindow::log(const QString& msg) {
    logArea->append("> " + msg);
    // Автопрокрутка вниз
    QTextCursor c = logArea->textCursor();
    c.movePosition(QTextCursor::End);
    logArea->setTextCursor(c);
}

void MainWindow::onSearch() {
    std::string keyword = searchEdit->text().toStdString();
    if (keyword.empty()) return;

    currentSearchResults = m_threats.search_by_keyword(keyword);
    searchModel->removeRows(0, searchModel->rowCount());

    for (const auto& t : currentSearchResults) {
        QList<QStandardItem*> row;
        row << new QStandardItem(QString::fromStdString(t.code));
        row << new QStandardItem(QString::fromStdString(t.title));
        row << new QStandardItem(QString::fromStdString(t.description));
        searchModel->appendRow(row);
    }
    log(QString("Найдено угроз: %1").arg(currentSearchResults.size()));
}

void MainWindow::onAddToReport() {
    int count = m_session.add(currentSearchResults);
    
    // Refresh report table
    // (In real app, optimize this, don't recreate all rows)
    reportModel->removeRows(0, reportModel->rowCount());
    // Accessing private map is tricky without friend class or getter
    // For demo, we just log. In real code, add "get_all()" to SearchSession.
    log(QString("Добавлено в отчет новых: %1").arg(count));
    
    // Hack: Add blindly to UI for visual confirmation
    for(const auto& t : currentSearchResults) {
         QList<QStandardItem*> row;
        row << new QStandardItem(QString::fromStdString(t.code));
        row << new QStandardItem(QString::fromStdString(t.title));
        reportModel->appendRow(row);
    }
}

void MainWindow::onExportReport() {
    if (m_session.size() == 0) {
        QMessageBox::information(this, "Info", "Отчет пуст");
        return;
    }
    QString path = QFileDialog::getSaveFileName(this, "Сохранить отчет", "report.csv", "CSV Files (*.csv)");
    if (path.isEmpty()) return;

    std::string err;
    if (m_session.export_csv(path.toStdString(), err)) {
        log("Экспорт успешен: " + path);
        QMessageBox::information(this, "Success", "Файл сохранен");
    } else {
        log("Ошибка экспорта: " + QString::fromStdString(err));
        QMessageBox::critical(this, "Error", QString::fromStdString(err));
    }
}

void MainWindow::onUpdateDatabase() {
    // В GUI долгие операции нельзя делать в главном потоке.
    // Но для курсовой сделаем здесь с вызовом processEvents, чтобы окно не висело намертво.
    
    log("Начало обновления БД...");
    QApplication::setOverrideCursor(Qt::WaitCursor);
    QApplication::processEvents();

    std::string err;
    // 1. Download & Convert (using functions from PDF listing)
    // NOTE: In real implementation, these functions need to be declared in headers included here.
    // I assume you copy-pasted `download_and_convert_csv` logic into a helper class or keep it static.
    // For now, let's pretend we have a Helper class or similar.
    
    // ВАЖНО: Функции `download_and_convert_csv` в PDF были static в main.cpp. 
    // Тебе нужно вынести их в отдельный .hpp/.cpp (например `src/update_manager.hpp`)
    // Ниже примерная логика вызова:
    
    const std::string url = "https://bdu.fstec.ru/files/documents/thrlist.xlsx";
    const std::string xlsx_path = "data/thrlist.xlsx";
    const std::string csv_path = "data/thrlist.csv";
    
    // Ensure dirs (mkdir)
    #ifdef _WIN32
        system("mkdir data >nul 2>nul");
    #else
        system("mkdir -p data >/dev/null 2>/dev/null");
    #endif

    if (!download_https(url, xlsx_path, err)) {
        log("Ошибка скачивания: " + QString::fromStdString(err));
        QApplication::restoreOverrideCursor();
        return;
    }
    log("Скачано: " + QString::fromStdString(xlsx_path));
    QApplication::processEvents();

    if (!convert_xlsx_to_csv(xlsx_path, csv_path, err)) {
        log("Ошибка конвертации: " + QString::fromStdString(err));
        QApplication::restoreOverrideCursor();
        return;
    }
    log("Конвертировано: " + QString::fromStdString(csv_path));
    QApplication::processEvents();

    ImportStats stats;
    std::string imp_err;
    if (!import_threats_csv(m_db, csv_path, m_user.id, stats, imp_err)) {
         log("Ошибка импорта: " + QString::fromStdString(imp_err));
    } else {
        log(QString("Импорт завершен. Добавлено: %1, Обновлено: %2").arg(stats.inserted).arg(stats.updated));
    }

    QApplication::restoreOverrideCursor();
}

void MainWindow::onRefreshHistory() {
     try {
        pqxx::work tx(m_db.conn());
        auto r = tx.exec(
            "SELECT ul.imported_at, u.login, ul.inserted, ul.updated, ul.source "
            "FROM update_log ul JOIN users u ON u.id = ul.user_id "
            "ORDER BY ul.imported_at DESC LIMIT 20"
        );
        
        historyModel->removeRows(0, historyModel->rowCount());
        for (const auto& row : r) {
            QList<QStandardItem*> items;
            items << new QStandardItem(QString::fromStdString(row[0].c_str()));
            items << new QStandardItem(QString::fromStdString(row[1].c_str()));
            items << new QStandardItem(QString::number(row[2].as<int>()));
            items << new QStandardItem(QString::number(row[3].as<int>()));
            items << new QStandardItem(QString::fromStdString(row[4].c_str()));
            historyModel->appendRow(items);
        }
    } catch (const std::exception& e) {
        log("Ошибка истории: " + QString::fromStdString(e.what()));
    }
}