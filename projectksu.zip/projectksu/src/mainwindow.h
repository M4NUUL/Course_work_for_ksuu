#pragma once
#include <QMainWindow>
#include <QStandardItemModel>
#include <QProgressBar> // <-- Добавляем хедер
#include "db.hpp"
#include "auth.hpp"
#include "threats.hpp"
#include "search_session.hpp"

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    MainWindow(Db& db, const User& user, QWidget *parent = nullptr);

private slots:
    void onSearch();
    void onAddToReport();
    void onExportReport();
    void onUpdateDatabase();
    void onRefreshHistory();

private:
    Db& m_db;
    User m_user;
    ThreatRepository m_threats;
    SearchSession m_session;

    class QLineEdit* searchEdit;
    class QTableView* searchTable;
    class QTableView* reportTable;
    class QTableView* historyTable;
    class QTextEdit* logArea;
    class QProgressBar* progressBar; // <-- Добавляем переменную

    QStandardItemModel* searchModel;
    QStandardItemModel* reportModel;
    QStandardItemModel* historyModel;

    std::vector<Threat> currentSearchResults;

    void setupUi();
    void log(const QString& msg);
};