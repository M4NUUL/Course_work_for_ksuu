#pragma once
#include <string>
#include <functional> // <--- ЭТОЙ СТРОКИ НЕ ХВАТАЛО

// Скачивает URL в filepath. 
// progress_cb - функция, которая принимает (скачано_байт, всего_байт)
bool download_https(const std::string& url, 
                    const std::string& filepath, 
                    std::string& error,
                    std::function<void(double, double)> progress_cb = nullptr);